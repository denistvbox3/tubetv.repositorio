import xbmcaddon

MainBase = 'https://pastebin.com/raw/eJHtX3AT'
addon = xbmcaddon.Addon('plugin.video.tubetv')