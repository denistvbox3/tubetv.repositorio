import xbmcaddon

MainBase = 'http://denistvbox3.blogspot.com.br/2018/04/home.html'
addon = xbmcaddon.Addon('plugin.video.tubetv')